<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReturnImages extends Model
{
    protected $table = 'return_images';
    protected $primaryKey = 'id';
    protected $guarded = ['id'];

}
