<?php return array (
  'admin_email' => 'aliasgargandhi5253@gmail.com',
  'default_currency' => 'INR',
  'return_days' => '10',
);