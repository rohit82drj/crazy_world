<?php



return [
    'image_optimize_module_name' => [
        'Banner',
        'Home-Banner',
        'Home-Category-Right',
        'Home-Category-Left',
        'About-us',
        'Main-Banner',
        'Product',
        'SizeChart',
        'Testimonial',
        'Ticket',
        'Blog-Image',
        'Blog-Banner',
        'Category',
        'Category Banner',
        'Mobile-Banner'
    ],
    'image_optimize_thumb_folder' => [
        'Big',
        'Medium',
        'Small',
        'Tiny',
    ],
];